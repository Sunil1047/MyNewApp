#!/bin/bash

cd /home/ubuntu/freshkhao
npm install