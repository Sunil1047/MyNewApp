#!/bin/bash

cd /home/ubuntu/freshkhao
echo "we are starting the server"


