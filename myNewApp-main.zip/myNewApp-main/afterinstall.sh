#!/bin/bash

cd /home/ubuntu/freshkhao
echo "creating build files"
npm -f run build

pm2 status

pm122

